import 'package:angular/angular.dart';
import 'package:angular_router/angular_router.dart';
import 'package:fire_chief_web/src/common/fire_chief_event.dart';
import 'package:fire_chief_web/src/component/main_page.dart';
import 'package:fire_chief_web/src/logger/logger.dart';

@Component(
  selector: 'tms-firechief',
  styleUrls: const ['fire_chief_app.css'],
  templateUrl: 'fire_chief_app.html',
  directives: const [
    CORE_DIRECTIVES,
    ROUTER_DIRECTIVES,
    MainPageComponent,
  ],
  providers: const [
    const Provider(FireChiefLogger, useClass: FireChiefLogger),
    const Provider(FireChiefEvent, useClass: FireChiefEvent),
  ],
)
class FireChiefAppComponent implements OnInit {
  FireChiefLogger _log;

  FireChiefAppComponent(this._log) {
    _log.loggerName = 'FireChiefAppComponent';
  }

  ngOnInit() {
    _log.fine('ngOnInit()');
  }
}
