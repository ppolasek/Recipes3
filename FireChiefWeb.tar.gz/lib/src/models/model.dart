import 'package:angular/angular.dart';

class DomainCommon {
  int id;
  int version;
  DateTime updatedOn;
  DateTime createdOn;

  bool isNew() => id == null || id < 0;

  @override
  String toString() {
    return 'id: $id, version: $version, updatedOn: $updatedOn, createdOn: $createdOn';
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
          other is DomainCommon &&
              runtimeType == other.runtimeType &&
              id == other.id;

  @override
  int get hashCode => id.hashCode;
}

class Reading { // this one does not extends DomainCommon
  int id;
  int pm25;
  int co;
  int o3;
  int co2;
  double temp;
  double hum;
  DateTime datetime;
  double alt;
  double lat;
  double lon;
  DateTime sattime;
  int fix;
  int satcount;
  String uuid;
  String nodename;
  int blvl;
  String macaddress;

  @override
  String toString() {
    return 'Reading{id: $id, pm25: $pm25, co: $co, o3: $o3, co2: $co2, temp: $temp, hum: $hum, datetime: $datetime, alt: $alt, lat: $lat, lon: $lon, sattime: $sattime, fix: $fix, satcount: $satcount, uuid: $uuid, nodename: $nodename, blvl: $blvl, macaddress: $macaddress}';
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || other is Reading && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;
}

class Sensor extends DomainCommon {
  String macaddress;
  String nodename;
  DateTime datetime;
  double alt;
  double lat;
  double lon;

  @override
  String toString() {
    return 'Sensor{${super.toString()}, macaddress: $macaddress, nodename: $nodename, datetime: $datetime, alt: $alt, lat: $lat, lon: $lon}';
  }
}
