import 'dart:async';
import 'package:angular/angular.dart';
import 'package:fire_chief_web/src/logger/logger.dart';
import 'package:fire_chief_web/src/models/model.dart';

enum CruEvent {
  key_event_type,
  key_reading,
  type_reading_selected, // a reading was selected in the table
}

/// Because Angular Dart events do not bubble up, using a separate event class to send
/// event notifications to where they are needed.  This class is injected.
@Injectable()
class FireChiefEvent implements OnDestroy {
  FireChiefLogger _log;

  Stream get eventStream => _fireChiefStreamController.stream;

  StreamController _fireChiefStreamController = new StreamController.broadcast();

  FireChiefEvent(this._log) {
    _log.loggerName = 'FireChiefEvent';
  }

  void ngOnDestroy() {
    _fireChiefStreamController.close();
  }

  void onShowDetails(Reading reading) {
    _fireChiefStreamController.add({
      CruEvent.key_event_type: CruEvent.type_reading_selected,
      CruEvent.key_reading: reading
    });
  }
}