import 'package:fire_chief_web/src/models/model.dart';

List<Reading> sensordata = [
  new Reading()
      ..id = 12
      ..nodename = "Sensor1"
      ..lon = -104.794044
      ..lat = 39.52334
      ..pm25 = 10
      ..co = 1
      ..o3 = 16
      ..co2 = 75
      ..temp = 78.8
      ..hum = 45.5
      ..datetime = new DateTime.fromMillisecondsSinceEpoch(1514153170544)
      ..alt = 1700.0
      ..sattime = new DateTime.fromMillisecondsSinceEpoch(1514153170544)
      ..fix = 1
      ..satcount = 6
      ..uuid = "9ed25862-a2b6-4cc6-838f-3e05f7272116"
      ..blvl = 90,
  new Reading()
      ..id = 13
      ..nodename = "Sensor2"
      ..lon = -104.00404
      ..lat = 39.003338
      ..pm25 = 10
      ..co = 1
      ..o3 = 16
      ..co2 = 75
      ..temp = 78.8
      ..hum = 45.5
      ..datetime = new DateTime.fromMillisecondsSinceEpoch(1514153170569)
      ..alt = 1700.0
      ..sattime = new DateTime.fromMillisecondsSinceEpoch(1514153170569)
      ..fix = 1
      ..satcount = 6
      ..uuid = "b9e13920-de0d-41e3-a1b9-9b5b1c10a618"
      ..blvl = 90,
  ];