import 'package:angular/angular.dart';
import 'package:angular_router/angular_router.dart';
import 'package:fire_chief_web/src/common/fire_chief_event.dart';
import 'package:fire_chief_web/src/component/main_panels/details/details.dart';
import 'package:fire_chief_web/src/component/main_panels/sensors/sensors.dart';
import 'package:fire_chief_web/src/component/main_panels/status_bar/status_panel.dart';
import 'package:fire_chief_web/src/component/main_panels/top_panel/top_panel.dart';
import 'package:fire_chief_web/src/models/model.dart';
import 'package:fire_chief_web/src/logger/logger.dart';

@Component(
  selector: 'tms-mainpage',
  styleUrls: const ['main_page.css'],
  templateUrl: 'main_page.html',
  directives: const [
    CORE_DIRECTIVES,
    ROUTER_DIRECTIVES,
    TopPanelComponent,
    StatusPanelComponent,
    SensorsComponent,
    DetailsComponent,
  ],
  providers: const [
    const Provider(FireChiefLogger, useClass: FireChiefLogger),
  ],
)
class MainPageComponent implements OnInit {
  final FireChiefLogger _log;
  final FireChiefEvent _cruEvent;

  // TODO this will come from the sensor's latest readings table when a row is selected and an event is thrown
  Reading selectedReading = new Reading()
    ..alt = 1609.344
    ..blvl = 95
    ..co = 10
    ..co2 = 15
    ..datetime = new DateTime.now()
    ..fix = 6
    ..hum = 26.3
    ..lat = 34.50
    ..lon = -104.5
    ..nodename = 'Sensor1'
    ..o3 = 15
    ..pm25 = 5
    ..satcount = 6
    ..sattime = new DateTime.now()
    ..temp = 75.3;


  MainPageComponent(this._log, this._cruEvent) {
    _log.loggerName = 'MainPageComponent';
  }

  ngOnInit() {
    _log.fine('ngOnInit()');
    _cruEvent.eventStream.listen((event) => _handleFireChiefEvents(event));
  }

  _handleFireChiefEvents(var event) {
    _log.fine('_handleFireChiefEvents() event = $event');

    if (event == null) return;

    switch (event[CruEvent.key_event_type]) {
      case CruEvent.type_reading_selected:
        selectedReading = event[CruEvent.key_reading];

        break;
    }
  }
}
