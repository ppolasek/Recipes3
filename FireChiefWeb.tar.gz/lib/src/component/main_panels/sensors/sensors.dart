import 'dart:html';
import 'package:angular/angular.dart';
import 'package:angular_router/angular_router.dart';
import 'package:fire_chief_web/src/component/tab_panels/sensor_table/sensor_table.dart';
import 'package:fire_chief_web/src/logger/logger.dart';

@Component(
  selector: 'tms-sensors',
  styleUrls: const ['sensors.css'],
  templateUrl: 'sensors.html',
  directives: const [
    CORE_DIRECTIVES,
    ROUTER_DIRECTIVES,
    SensorTableComponent,
  ],
  providers: const [
    const Provider(FireChiefLogger, useClass: FireChiefLogger),
  ],
)
class SensorsComponent implements OnInit {
  FireChiefLogger _log;

  String tabkey = '';

  SensorsComponent(this._log) {
    _log.loggerName = 'SensorsComponent';
  }

  ngOnInit() {
    _log.fine('ngOnInit()');
  }

  tabclick(MouseEvent event) {
    _log.fine('tabclick() event = $event');
//    _log.fine('tabclick() event = ${event.currentTarget.attributes['tabkey']}');
//    _log.fine('tabclick() tabkey = $tabkey');

// Don't do this:    event.stopPropagation();

  }
}
