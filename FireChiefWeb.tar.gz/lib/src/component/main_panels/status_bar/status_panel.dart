import 'package:angular/angular.dart';
import 'package:angular_router/angular_router.dart';
import 'package:fire_chief_web/src/logger/logger.dart';

@Component(
  selector: 'tms-status-panel',
  styleUrls: const ['status_panel.css'],
  templateUrl: 'status_panel.html',
  directives: const [
    CORE_DIRECTIVES,
    ROUTER_DIRECTIVES,
  ],
  providers: const [
    const Provider(FireChiefLogger, useClass: FireChiefLogger),
  ],
)
class StatusPanelComponent implements OnInit {
  FireChiefLogger _log;

  StatusPanelComponent(this._log) {
    _log.loggerName = 'StatusPanelComponent';
  }

  ngOnInit() {
    _log.fine('ngOnInit()');
  }
}
