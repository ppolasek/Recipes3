import 'package:angular/angular.dart';
import 'package:angular_router/angular_router.dart';
import 'package:fire_chief_web/src/models/model.dart';
import 'package:fire_chief_web/src/logger/logger.dart';

@Component(
  selector: 'tms-details',
  styleUrls: const ['details.css'],
  templateUrl: 'details.html',
  directives: const [
    CORE_DIRECTIVES,
    ROUTER_DIRECTIVES,
  ],
  providers: const [
    const Provider(FireChiefLogger, useClass: FireChiefLogger),
  ],
)
class DetailsComponent implements OnInit {
  FireChiefLogger _log;

  @Input()
  Reading reading;

  bool collapsed = false;

  DetailsComponent(this._log) {
    _log.loggerName = 'DetailsComponent';
  }

  ngOnInit() {
    _log.fine('ngOnInit()');
  }

  toggleCollapsed() {
    collapsed = !collapsed;
  }

  onPanelMouseover() {}

  onPanelMouseout() {}
}
