import 'package:angular/angular.dart';
import 'package:angular_router/angular_router.dart';
import 'package:fire_chief_web/src/logger/logger.dart';

@Component(
  selector: 'tms-top-panel',
  styleUrls: const ['top_panel.css'],
  templateUrl: 'top_panel.html',
  directives: const [
    CORE_DIRECTIVES,
    ROUTER_DIRECTIVES,
  ],
  providers: const [
    const Provider(FireChiefLogger, useClass: FireChiefLogger),
  ],
)
class TopPanelComponent implements OnInit {
  FireChiefLogger _log;

  TopPanelComponent(this._log) {
    _log.loggerName = 'TopPanelComponent';
  }

  ngOnInit() {
    _log.fine('ngOnInit()');
  }
}
