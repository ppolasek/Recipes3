import 'dart:async';
import 'dart:html';
import 'package:angular/angular.dart';
import 'package:angular_router/angular_router.dart';
import 'package:fire_chief_web/src/common/fire_chief_event.dart';
import 'package:fire_chief_web/src/logger/logger.dart';
import 'package:fire_chief_web/src/data/sensordata.dart';
import 'package:fire_chief_web/src/models/model.dart';

@Component(
  selector: 'tms-sensor-table',
  styleUrls: const ['sensor_table.css'],
  templateUrl: 'sensor_table.html',
  directives: const [
    CORE_DIRECTIVES,
    ROUTER_DIRECTIVES,
  ],
  providers: const [
    const Provider(FireChiefLogger, useClass: FireChiefLogger),
  ],
)
class SensorTableComponent implements OnInit, OnDestroy {
  FireChiefLogger _log;
  final FireChiefEvent _cruEvent;

  List<Reading> readings = <Reading>[];

  Reading selectedReading;
  String selectedBackgroundColor = 'inherit';
  String _oldBackgroundColor = '';

  SensorTableComponent(this._log, this._cruEvent) {
    _log.loggerName = 'SensorTableComponent';
  }

  ngOnInit() {
    _log.fine('ngOnInit()');
    _getSensorReadings();
  }

  @override
  ngOnDestroy() {
  }

  onRowClick(Reading reading) {
    _log.fine('onRowClick() reading.nodename = ${reading?.nodename}');

//    selectedBackgroundColor = selectedReading != null && selectedReading == reading ? 'inherit' : '#e6ffee';

    // TODO take the selected row and pass it to the details component
    // TODO change the background of the selected row
    // TODO if de-selecting, remove the background color
    if (selectedReading == reading) {
      selectedReading = null;
    } else {
      selectedReading = reading;
    }
    _cruEvent.onShowDetails(selectedReading);
    _log.fine('onRowClick() selectedReading.nodename = ${selectedReading?.nodename}');
  }

  getBackgroundColor(Reading reading) {
    return selectedReading != null && selectedReading == reading ? '#e6ffee' : 'inherit';
  }

  onMouseOver(Reading reading) {
    _oldBackgroundColor = getBackgroundColor(reading);
    selectedBackgroundColor = '#e6ffee';
  }

  onMouseOut() {
    selectedBackgroundColor = 'inherit';
  }

  _getSensorReadings() {
    readings = sensordata; // sensor data is dummy data from src/data/sensordata.dart until I hook up the service
  }
}
