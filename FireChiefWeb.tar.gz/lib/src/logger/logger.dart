// Copyright (c) 2017, ppolasek. All rights reserved. Use of this source code
// is governed by a BSD-style license that can be found in the LICENSE file.

import 'package:angular/angular.dart';
import 'package:logging/logging.dart';

@Injectable()
class FireChiefLogger {
  Logger _logger;
  String _loggerName = '';

  FireChiefLogger() : super() {
    log(Level.FINE, 'FireChiefLogger()');
  }

  void set loggerName(String newName) {
    _logger = new Logger(newName);
    _loggerName = newName;
    log(Level.FINE, 'FireChiefLogger() set loggerName = $newName');
  }

  bool isLoggable(Level value) => _logger.isLoggable(value);
  
  void log(Level level, message, [Object error, StackTrace stackTrace]) {
//    print('send this to the database: $level, $message');
//    _loggerService?.log(_loggerName, new DateTime.now(), level.toString(), message, error, stackTrace);
    _logger?.log(level, message, error, stackTrace);
//    print('$_loggerName $level $message');
  }

  void config(message, [Object error, StackTrace stackTrace]) {
    log(Level.CONFIG, message, error, stackTrace);
  }

  void fine(message, [Object error, StackTrace stackTrace]) {
    log(Level.FINE, message, error, stackTrace);
  }

  void finer(message, [Object error, StackTrace stackTrace]) {
    log(Level.FINER, message, error, stackTrace);
  }

  void finest(message, [Object error, StackTrace stackTrace]) {
    log(Level.FINEST, message, error, stackTrace);
  }

  void info(message, [Object error, StackTrace stackTrace]) {
    log(Level.INFO, message, error, stackTrace);
  }

  void warning(message, [Object error, StackTrace stackTrace]) {
    log(Level.WARNING, message, error, stackTrace);
  }

  void severe(message, [Object error, StackTrace stackTrace]) {
    log(Level.SEVERE, message, error, stackTrace);
  }

  void shout(message, [Object error, StackTrace stackTrace]) {
    log(Level.SHOUT, message, error, stackTrace);
  }

  String toString() {
    return 'FireChiefLogger($_loggerName) level: ${_logger.level} fullName: ${_logger.fullName}';
  }
}